using System;
using System.Collections.Generic;
using System.IO;

class Konyv
{
    public string Cim, Szerzo;
    public int Ev;
    public bool Elerheto;

    public Konyv(string cim, string szerzo, int ev, bool elerheto)
    {
        Cim = cim;
        Szerzo = szerzo;
        Ev = ev;
        Elerheto = elerheto;
    }
}

class Program
{
    static void Main()
    {
        List<Konyv> konyvek = new List<Konyv>();
        foreach (string sor in File.ReadAllLines("konyvek.txt"))
        {
            string[] adat = sor.Split(';');
            if (adat[0] == "Azonosito") continue;
            konyvek.Add(new Konyv(adat[1], adat[2], int.Parse(adat[3]), adat[5] == "igen"));
        }

        Console.WriteLine("1 - Osszes konyv");
        Console.WriteLine("2 - Elerheto konyvek");
        Console.WriteLine("3 - Kereses cim szerint");
        Console.Write("Valasztas: ");
        string valasz = Console.ReadLine();

        if (valasz == "1")
        {
            foreach (Konyv k in konyvek)
                Console.WriteLine(k.Cim + " - " + k.Szerzo + " (" + k.Ev + ")");
        }
        else if (valasz == "2")
        {
            foreach (Konyv k in konyvek)
                if (k.Elerheto) Console.WriteLine(k.Cim + " - " + k.Szerzo);
        }
        else if (valasz == "3")
        {
            Console.Write("Keresett cim: ");
            string keres = Console.ReadLine().ToLower();
            foreach (Konyv k in konyvek)
                if (k.Cim.ToLower().Contains(keres))
                    Console.WriteLine(k.Cim + " - " + k.Szerzo);
        }
        else
        {
            Console.WriteLine("Hibas valasztas.");
        }
    }
}